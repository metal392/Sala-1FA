function dados() {
    //Dicionário de dados
    const ds = [
        { id: 1, login: 'Benimaru', senha: '1234', nome: 'Benimaru Shinmon', email: 'wakashinmon123@ig.com' }, //0
        { id: 2, login: 'Shinra', senha: 'Pégafogo', nome: 'Shinra Kusakabe', email: 'shinra.kusakabe@ig.com' }, //1
        { id: 3, login: 'Ogun', senha: 'Yoruba123', nome: 'Ogun Mountgomery', email: 'ogun.mountgomery@ig.com' } //2
    ]

let json = JSON.stringify(ds);

localStorage.setItem('dados', json);

}

function logar() {
    const ds = JSON.parse(localStorage.getItem('dados'))

    let lg = document.querySelector('#Login').value
    let sn= document.querySelector('#senha').value
 

    //alert(lg + "\n" + sn)
    
    for (let i=0;i<ds.length;i++){

    if(lg == ds[i].login && sn == ds[i].senha){
        alert("SAPORRA FOI CARALHO!!!")
        }
    }

}